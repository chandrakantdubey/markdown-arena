/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// Helper to convert topic names to filename slugs
export function slugify(text) {
  return text.toLowerCase()
      .replace(/\s+/g, '-') // Replace spaces with -
      .replace(/[^\w-]+/g, ''); // Remove all non-word chars
}
