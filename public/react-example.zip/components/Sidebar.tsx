/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
export function Sidebar({
  sections,
  searchTerm,
  onSearchTermChange,
  searchResults,
  activeTopic,
  isTopicViewed,
  onTopicClick,
  prefetchTopic,
  openSection,
  onToggleSection,
  onOpenGlossary,
}) {
  return (
    <nav className="sidebar" aria-label="Table of Contents">
      <div>
        <h1>BlueRabbit</h1>
        <div className="search-container">
          <input
            type="search"
            placeholder="Search topics..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => onSearchTermChange(e.target.value)}
            aria-label="Search topics"
          />
        </div>
        {searchTerm ? (
          <ul className="search-results-list topic-list open">
            {searchResults.length > 0 ? searchResults.map(topic => (
              <li key={topic}>
                <button
                    className={
                        `topic-button ${activeTopic === topic ? 'active' : ''} ${isTopicViewed(topic) ? 'viewed' : ''}`
                    }
                    onClick={() => onTopicClick(topic)}
                    onMouseEnter={() => prefetchTopic(topic)}
                    aria-current={activeTopic === topic ? 'page' : undefined}>
                  {topic}
                </button>
              </li>
            )) : <li className="no-results">No results found.</li>}
          </ul>
        ) : sections.map((section) => (
            <div key={section.title} className="section">
              <button
                  className={`section-button ${
                      openSection === section.title ? 'open' : ''}`}
                  onClick={() => onToggleSection(section.title)}
                  aria-expanded={openSection === section.title}
                  aria-controls={`section-content-${
                      section.title.replace(/\s/g, '-')}`}>
                <span>{section.title}</span>
                <span className="arrow" aria-hidden="true">
                  {'❯'}
                </span>
              </button>
              <ul
                  id={`section-content-${section.title.replace(/\s/g, '-')}`}
                  className={
                      `topic-list ${openSection === section.title ? 'open' : ''}`
                  }>
                {section.topics.map((topic) => (
                    <li key={topic}>
                      <button
                          className={
                              `topic-button ${activeTopic === topic ? 'active' : ''} ${isTopicViewed(topic) ? 'viewed' : ''}`
                          }
                          onClick={() => onTopicClick(topic)}
                          onMouseEnter={() => prefetchTopic(topic)}
                          aria-current={activeTopic === topic ? 'page' : undefined}>
                        {topic}
                      </button>
                    </li>
                ))}
              </ul>
            </div>
        ))}
      </div>
      <div className="sidebar-footer">
        <button className="glossary-button" onClick={onOpenGlossary}>
          View Glossary
        </button>
      </div>
    </nav>
  );
}