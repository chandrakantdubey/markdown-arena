/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import {useEffect, useState, useRef} from 'react';
import {marked} from 'marked';
import hljs from 'highlight.js';
import mermaid from 'mermaid';

// The `highlight` option is not a valid top-level property for `marked.setOptions` in recent versions.
// The modern approach is to configure `marked` using `marked.use()` for global
// options like syntax highlighting. This configures the highlighter for all subsequent
// calls to `marked.parse()` across the application.
marked.use({
  renderer: {
    // Corrected the function signature to match `marked`'s token-based renderer API.
    // When using `marked.use()`, the `code` function receives a single token object.
    // We destructure `text` (renaming it to `code`) and `lang` from the token.
    // The `lang` property on a marked `Code` token is optional and may not be present.
    // Changed `lang: string | undefined` to `lang?: string` to correctly type it as an optional property.
    code({ text: code, lang }: { text: string; lang?: string; }) {
      const language = lang && hljs.getLanguage(lang) ? lang : 'plaintext';
      const highlightedCode = hljs.highlight(code, { language }).value;
      return `<pre><code class="hljs language-${language}">${highlightedCode}</code></pre>`;
    },
  },
});

// Configure Mermaid
mermaid.initialize({
  startOnLoad: false,
  theme: 'base',
  themeVariables: {
    background: '#0d1b2a',
    primaryColor: '#1b263b',
    primaryTextColor: '#e0e1dd',
    primaryBorderColor: '#415a77',
    lineColor: '#415a77',
    secondaryColor: '#ffc300',
    tertiaryColor: '#1b263b',
    textColor: '#e0e1dd',
    mainBkg: '#1b263b',
    errorBkgColor: '#532020',
    errorTextColor: '#e0e1dd'
  }
});

export function MarkdownRenderer({ markdownContent, onAiAction, glossary, onTermClick }) {
  const [htmlContent, setHtmlContent] = useState('');
  const contentRef = useRef(null);

  useEffect(() => {
    // More robustly handle markdown parsing.
    // If the content is not a string, clear the HTML and do nothing.
    if (typeof markdownContent !== 'string') {
      setHtmlContent('');
      return;
    }

    const parseMarkdown = async () => {
      try {
        const html = await marked.parse(markdownContent);
        setHtmlContent(String(html));
      } catch (e) {
        console.error("Error parsing markdown:", e);
        setHtmlContent('<p class="error">Error rendering content.</p>');
      }
    };
    parseMarkdown();
  }, [markdownContent]);

  // Effect to handle Mermaid rendering, code tab interactivity, and AI button injection
  useEffect(() => {
    const contentEl = contentRef.current;
    if (!contentEl) return;
    
    // Render diagrams
    try {
      const mermaidElements = contentEl.querySelectorAll('code.language-mermaid');
      mermaidElements.forEach((el, i) => {
        const id = `mermaid-diagram-${Date.now()}-${i}`;
        const code = el.textContent;
        const container = document.createElement('div');
        container.id = id;
        container.className = 'mermaid-diagram';
        if (el.parentElement) {
          el.parentElement.replaceWith(container);
        }
        mermaid.render(id, code)
          .then(({svg}) => { container.innerHTML = svg; })
          .catch(err => {
            console.error(`Mermaid render failed for diagram ${i}:`, err);
            container.innerHTML = `<p class="error">Error rendering diagram.</p>`;
          });
      });
    } catch (e) {
      console.error("Failed to process mermaid diagrams", e);
    }

    // Add interactivity to code tabs
    const tabContainers = contentEl.querySelectorAll('.code-tabs');
    tabContainers.forEach(container => {
      const buttons = container.querySelectorAll('.tab-button');
      const contents = container.querySelectorAll('.tab-content');
      buttons.forEach(button => {
        button.addEventListener('click', () => {
          const lang = button.getAttribute('data-lang');
          buttons.forEach(btn => btn.classList.remove('active'));
          button.classList.add('active');
          contents.forEach(content => {
            if (content.getAttribute('data-lang') === lang) {
              content.classList.add('active');
            } else {
              content.classList.remove('active');
            }
          });
        });
      });
    });

    // Inject "Explain" buttons for headings
    contentEl.querySelectorAll('h2, h3').forEach(heading => {
      // Avoid adding buttons to special sections like "Further Reading"
      if (heading.closest('.further-reading')) return;
      
      const button = document.createElement('button');
      button.className = 'ai-button explain-button';
      button.textContent = 'Explain with AI ✨';
      button.onclick = () => {
          let content = '';
          let nextEl = heading.nextElementSibling;
          while(nextEl && nextEl.tagName !== 'H2' && nextEl.tagName !== 'H3') {
              // We'll take the text content to create a cleaner prompt
              content += nextEl.textContent + '\n';
              nextEl = nextEl.nextElementSibling;
          }
          const prompt = `Explain the following concept about "${heading.textContent}" in simple terms, as if you were talking to a beginner learning backend development. Use markdown for formatting your response.\n\nCONTENT:\n${content}`;
          onAiAction(prompt);
      };
      heading.appendChild(button);
    });

    // Inject "Dissect" buttons for code blocks
    contentEl.querySelectorAll('pre').forEach(pre => {
        const parent = pre.parentElement;
        // Don't add to code tabs, as they have their own structure
        if (parent.classList.contains('tab-content')) return;

        const button = document.createElement('button');
        button.className = 'ai-button dissect-button';
        button.textContent = 'Dissect this code ✨';
        button.onclick = () => {
            const code = pre.querySelector('code')?.textContent || '';
            const langClass = pre.querySelector('code')?.className || '';
            const language = langClass.replace('language-', '');
            const prompt = `Explain this ${language} code snippet line-by-line for a beginner. Use markdown for formatting your response, including code blocks for each line.\n\nCODE:\n\`\`\`${language}\n${code}\n\`\`\``;
            onAiAction(prompt);
        };
        // Insert button before the <pre> tag
        parent.insertBefore(button, pre);
    });

    // Glossary cross-linking
    if (glossary && glossary.size > 0 && onTermClick) {
        const processedTerms = new Set();
        // Process longer terms first to avoid partial matches (e.g., "API" inside "API Gateway")
        // Explicitly cast glossary keys to string array to fix 'unknown' type error.
        const terms = (Array.from(glossary.keys()) as string[]).sort((a, b) => b.length - a.length);

        contentEl.querySelectorAll('p, li, blockquote, td').forEach(node => {
            let html = node.innerHTML;
            let replaced = false;
            for (const term of terms) {
                if (!processedTerms.has(term.toLowerCase())) {
                    // Case-insensitive, whole-word match that is not inside an HTML tag
                    const regex = new RegExp(`\\b(${term})\\b(?![^<]*?>)`, 'i');
                    if (regex.test(html)) {
                        html = html.replace(regex, (match) => 
                            `<button class="term-link" data-term="${match}">${match}</button>`
                        );
                        processedTerms.add(term.toLowerCase());
                        replaced = true;
                        // Break after first replacement in a paragraph to reduce noise
                        break; 
                    }
                }
            }
            if (replaced) {
                node.innerHTML = html;
            }
        });
    }

    // Event delegation for term links
    const handleContentClick = (e) => {
        if (e.target.classList.contains('term-link')) {
            const term = e.target.dataset.term;
            onTermClick(term, e);
        }
    };
    contentEl.addEventListener('click', handleContentClick);


    return () => {
      // Clean up all dynamically added event listeners
      contentEl.removeEventListener('click', handleContentClick);
      // Other cleanup can be added here if needed
    };

  }, [htmlContent, onAiAction, glossary, onTermClick]);

  return (
    <div
      ref={contentRef}
      className="markdown-body"
      dangerouslySetInnerHTML={{__html: htmlContent}}
    />
  );
}