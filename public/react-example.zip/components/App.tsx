/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import {useEffect, useState, useCallback, useMemo} from 'react';
import { Sidebar } from './Sidebar.js';
import { Content } from './Content.js';
import { AiModal } from './AiModal.js';
import { QuizModal } from './QuizModal.js';
import { GlossaryModal } from './GlossaryModal.js';
import { DefinitionTooltip } from './DefinitionTooltip.js';
import { slugify } from '../utils/slugify.js';

async function fetchMarkdownData(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to load markdown data from ${url}`);
  }
  return await response.text();
}

function parseMarkdownTopics(markdown) {
  const sections = [];
  let currentSection = null;
  const lines = markdown.split('\n');

  for (const line of lines) {
    const sectionMatch = line.match(/^### \*\*(.*)\*\*/);
    if (sectionMatch) {
      if (currentSection) {
        sections.push(currentSection);
      }
      currentSection = {title: sectionMatch[1].trim(), topics: []};
      continue;
    }

    const topicMatch = line.match(/^\d+\.\s+\*\*(.*)\*\*/);
    if (topicMatch && currentSection) {
      currentSection.topics.push(topicMatch[1].trim());
    }
  }

  if (currentSection?.topics.length > 0) {
    sections.push(currentSection);
  }
  return sections;
};

function parseGlossaryMarkdown(markdown) {
  const glossary = new Map();
  const lines = markdown.split('\n');
  let currentTerm = null;
  let currentDefinition = '';

  for (const line of lines) {
    const termMatch = line.match(/^### (.*)/);
    if (termMatch) {
      if (currentTerm && currentDefinition) {
        glossary.set(currentTerm, currentDefinition.trim());
      }
      currentTerm = termMatch[1].trim();
      currentDefinition = '';
    } else if (currentTerm) {
      currentDefinition += line + '\n';
    }
  }
  if (currentTerm && currentDefinition) {
    glossary.set(currentTerm, currentDefinition.trim());
  }
  return glossary;
}


export function App() {
  const [sections, setSections] = useState([]);
  const [glossary, setGlossary] = useState(new Map());
  const [activeTopic, setActiveTopic] = useState(null);
  const [generatedContent, setGeneratedContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [openSection, setOpenSection] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewedTopics, setViewedTopics] = useState(new Set());

  // State for AI Explanation Modal
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');

  // State for AI Quiz Modal
  const [isQuizModalOpen, setIsQuizModalOpen] = useState(false);
  const [quizTopicContent, setQuizTopicContent] = useState({ title: '', content: '' });

  // State for Glossary
  const [isGlossaryModalOpen, setIsGlossaryModalOpen] = useState(false);
  const [tooltipState, setTooltipState] = useState({ visible: false, content: '', x: 0, y: 0 });


  // Load viewed topics from localStorage on initial render
  useEffect(() => {
    try {
      const stored = localStorage.getItem('viewedTopics');
      if (stored) {
        setViewedTopics(new Set(JSON.parse(stored)));
      }
    } catch (e) {
      console.error("Failed to parse viewed topics from localStorage", e);
      localStorage.removeItem('viewedTopics');
    }
  }, []);

  useEffect(() => {
    async function loadInitialData() {
      try {
        // Load topics for sidebar
        const topicMarkdown = await fetchMarkdownData('./data.md');
        const parsedSections = parseMarkdownTopics(topicMarkdown);
        setSections(parsedSections);
        if (parsedSections.length > 0) {
          setOpenSection(parsedSections[0].title);
        }

        // Load glossary
        const glossaryMarkdown = await fetchMarkdownData('./content/glossary.md');
        const parsedGlossary = parseGlossaryMarkdown(glossaryMarkdown);
        setGlossary(parsedGlossary);

      } catch(e) {
        setError('Could not load initial data. Make sure data.md and glossary.md exist.');
        console.error(e);
      }
    }
    loadInitialData();
  }, []);

  const handleTopicClick = async (topic) => {
    if (isLoading && topic === activeTopic) return;
    setActiveTopic(topic);
    setIsLoading(true);
    setGeneratedContent('');
    setError('');
    handleCloseTooltip(); // Close tooltip on navigation

    try {
      const slug = slugify(topic);
      const response = await fetch(`./content/${slug}.md`);

      if (!response.ok) {
        throw new Error(`Content for "${
            topic}" not found. Create a file at ./content/${slug}.md`);
      }

      const markdownContent = await response.text();
      // Use a small delay to allow the loader to be visible, improving UX for fast loads
      setTimeout(() => {
        setGeneratedContent(markdownContent);
        setIsLoading(false);

        // Add to viewed topics on success
        const newViewed = new Set(viewedTopics);
        newViewed.add(slug);
        setViewedTopics(newViewed);
        localStorage.setItem('viewedTopics', JSON.stringify(Array.from(newViewed)));

      }, 200);

    } catch (e) {
      console.error(e);
      setError(e.message);
      setIsLoading(false);
    }
  };

  const prefetchTopic = useCallback((topic) => {
    const slug = slugify(topic);
    fetch(`./content/${slug}.md`);
  }, []);

  const isTopicViewed = useCallback((topic) => {
      return viewedTopics.has(slugify(topic));
  }, [viewedTopics]);


  const handleToggleSection = (sectionTitle) => {
    setOpenSection(openSection === sectionTitle ? null : sectionTitle);
  };
  
  const handleRoadmapTopicClick = (topic) => {
    // Find which section the topic belongs to and expand it in the sidebar
    const section = sections.find(s => s.topics.includes(topic));
    if (section && openSection !== section.title) {
        setOpenSection(section.title);
    }
    // Load the topic content
    handleTopicClick(topic);
  };

  const searchResults = useMemo(() => {
    if (!searchTerm) return [];
    return sections
      .flatMap(section => section.topics)
      .filter(topic => topic.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [searchTerm, sections]);

  // AI Modal Handlers
  const handleAiAction = (prompt) => {
    setAiPrompt(prompt);
    setIsAiModalOpen(true);
  };
  const closeAiModal = () => {
    setIsAiModalOpen(false);
    setAiPrompt('');
  };

  // Quiz Modal Handlers
  const handleGenerateQuiz = (topicTitle, topicContent) => {
    setQuizTopicContent({ title: topicTitle, content: topicContent });
    setIsQuizModalOpen(true);
  };
  const closeQuizModal = () => {
    setIsQuizModalOpen(false);
    setQuizTopicContent({ title: '', content: '' });
  };

  // Glossary and Tooltip Handlers
  const handleOpenGlossary = () => setIsGlossaryModalOpen(true);
  const handleCloseGlossary = () => setIsGlossaryModalOpen(false);

  const handleTermClick = useCallback((term, event) => {
      // Find the correct term case-insensitively from the glossary Map keys
      const glossaryTerm = Array.from(glossary.keys()).find(key => key.toLowerCase() === term.toLowerCase());
      const definition = glossary.get(glossaryTerm);
      if (definition) {
        const rect = event.target.getBoundingClientRect();
        setTooltipState({
            visible: true,
            content: definition,
            x: rect.left,
            y: rect.bottom + window.scrollY + 5, // Position below the term
        });
      }
  }, [glossary]);

  const handleCloseTooltip = () => {
      setTooltipState(prevState => ({ ...prevState, visible: false }));
  };

  useEffect(() => {
    const close = () => setTooltipState(prevState => ({ ...prevState, visible: false }));
    if (tooltipState.visible) {
      window.addEventListener('scroll', close, true); // Use capture to catch early
      window.addEventListener('click', close);
    }
    return () => {
      window.removeEventListener('scroll', close, true);
      window.removeEventListener('click', close);
    };
  }, [tooltipState.visible]);

  return (
      <div className="container">
        <Sidebar
          sections={sections}
          searchTerm={searchTerm}
          onSearchTermChange={setSearchTerm}
          searchResults={searchResults}
          activeTopic={activeTopic}
          isTopicViewed={isTopicViewed}
          onTopicClick={handleTopicClick}
          prefetchTopic={prefetchTopic}
          openSection={openSection}
          onToggleSection={handleToggleSection}
          onOpenGlossary={handleOpenGlossary}
        />
        <Content
          isLoading={isLoading}
          error={error}
          generatedContent={generatedContent}
          sections={sections}
          activeTopic={activeTopic}
          onRoadmapTopicClick={handleRoadmapTopicClick}
          isTopicViewed={isTopicViewed}
          prefetchTopic={prefetchTopic}
          onTopicClick={handleTopicClick}
          onAiAction={handleAiAction}
          onGenerateQuiz={handleGenerateQuiz}
          glossary={glossary}
          onTermClick={handleTermClick}
        />
        <AiModal
          isOpen={isAiModalOpen}
          prompt={aiPrompt}
          onClose={closeAiModal}
        />
        <QuizModal
          isOpen={isQuizModalOpen}
          topicTitle={quizTopicContent.title}
          topicContent={quizTopicContent.content}
          onClose={closeQuizModal}
        />
        <GlossaryModal
          isOpen={isGlossaryModalOpen}
          onClose={handleCloseGlossary}
          glossary={glossary}
        />
        <DefinitionTooltip
          visible={tooltipState.visible}
          content={tooltipState.content}
          x={tooltipState.x}
          y={tooltipState.y}
        />
      </div>
  );
}