/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useMemo } from 'react';

export function TopicNavigation({ sections, activeTopic, onTopicClick }) {
  const allTopics = useMemo(() => sections.flatMap(section => section.topics), [sections]);

  if (!activeTopic) {
    return null;
  }

  const currentIndex = allTopics.indexOf(activeTopic);

  const prevTopic = currentIndex > 0 ? allTopics[currentIndex - 1] : null;
  const nextTopic = currentIndex < allTopics.length - 1 ? allTopics[currentIndex + 1] : null;

  return (
    <nav className="topic-navigation" aria-label="Lesson navigation">
      {prevTopic && (
        <button className="nav-button prev" onClick={() => onTopicClick(prevTopic)}>
          <span className="arrow" aria-hidden="true">←</span>
          <span className="label">Previous</span>
          <span className="topic-name">{prevTopic}</span>
        </button>
      )}
      {nextTopic && (
        <button className="nav-button next" onClick={() => onTopicClick(nextTopic)}>
          <span className="topic-name">{nextTopic}</span>
          <span className="label">Next</span>
          <span className="arrow" aria-hidden="true">→</span>
        </button>
      )}
    </nav>
  );
}
