/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export function DefinitionTooltip({ visible, content, x, y }) {
  if (!visible) {
    return null;
  }

  const style = {
    left: `${x}px`,
    top: `${y}px`,
    // Basic transform to keep it on screen, can be improved
    transform: `translateX(-20%)`, 
  };

  return (
    <div className="definition-tooltip" style={style}>
      {content}
    </div>
  );
}