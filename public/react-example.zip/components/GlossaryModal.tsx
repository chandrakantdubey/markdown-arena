/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useMemo } from 'react';

export function GlossaryModal({ isOpen, onClose, glossary }) {
  
  const sortedGlossary = useMemo(() => {
    return Array.from(glossary.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [glossary]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="glossary-modal-overlay" onClick={onClose}>
      <div className="glossary-modal" onClick={(e) => e.stopPropagation()}>
        <div className="glossary-modal-header">
          <h3>Glossary of Terms</h3>
          <button onClick={onClose} className="glossary-modal-close-button" aria-label="Close modal">&times;</button>
        </div>
        <div className="glossary-modal-content">
          {sortedGlossary.length > 0 ? (
            <dl>
              {sortedGlossary.map(([term, definition]) => (
                <>
                  <dt key={term}>{term}</dt>
                  <dd>{definition}</dd>
                </>
              ))}
            </dl>
          ) : (
            <p>No glossary terms have been loaded.</p>
          )}
        </div>
      </div>
    </div>
  );
}