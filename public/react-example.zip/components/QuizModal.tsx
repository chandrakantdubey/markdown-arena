/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useEffect, useState } from 'react';
import { GoogleGenAI, Type } from '@google/genai';

const quizSchema = {
  type: Type.OBJECT,
  properties: {
    questions: {
      type: Type.ARRAY,
      description: 'An array of quiz questions.',
      items: {
        type: Type.OBJECT,
        properties: {
          question: {
            type: Type.STRING,
            description: 'The question text.',
          },
          options: {
            type: Type.ARRAY,
            description: 'An array of possible answers.',
            items: {
              type: Type.STRING,
            }
          },
          correctAnswer: {
            type: Type.STRING,
            description: 'The correct answer, which must be one of the options.',
          },
          explanation: {
            type: Type.STRING,
            description: 'A brief explanation of why the answer is correct.',
          }
        },
        required: ['question', 'options', 'correctAnswer', 'explanation']
      }
    }
  },
  required: ['questions']
};


export function QuizModal({ isOpen, topicTitle, topicContent, onClose }) {
  const [quizData, setQuizData] = useState(null);
  const [userAnswers, setUserAnswers] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen || !topicContent) {
      // Reset state when modal is not open or content is not ready
      setQuizData(null);
      setUserAnswers({});
      setError('');
      return;
    }

    const generateQuiz = async () => {
      setIsLoading(true);
      setError('');
      setQuizData(null);

      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `You are an expert educator creating a quiz. Based on the following content about "${topicTitle}", generate a 3-question multiple-choice quiz. The quiz should test the key concepts from the text. Return a single JSON object that strictly follows the provided schema. The 'correctAnswer' field must exactly match one of the strings in the 'options' array.

        CONTENT:
        ---
        ${topicContent}
        ---`;

        const result = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: quizSchema,
          },
        });
        
        const parsedJson = JSON.parse(result.text);
        setQuizData(parsedJson.questions);

      } catch (e) {
        console.error("Gemini API call for quiz failed", e);
        setError('Sorry, the AI is unable to generate a quiz at the moment. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    generateQuiz();
  }, [isOpen, topicTitle, topicContent]);

  const handleAnswerSelect = (questionIndex, selectedOption) => {
    if (userAnswers[questionIndex] !== undefined) return; // Already answered

    setUserAnswers(prev => ({
        ...prev,
        [questionIndex]: selectedOption,
    }));
  };

  const getButtonClass = (questionIndex, option) => {
      const answered = userAnswers[questionIndex] !== undefined;
      if (!answered) return '';

      const correctAnswer = quizData[questionIndex].correctAnswer;
      const selectedAnswer = userAnswers[questionIndex];

      if (option === correctAnswer) return 'correct';
      if (option === selectedAnswer && option !== correctAnswer) return 'incorrect';
      return '';
  };


  if (!isOpen) {
    return null;
  }

  return (
    <div className="quiz-modal-overlay" onClick={onClose}>
      <div className="quiz-modal" onClick={(e) => e.stopPropagation()}>
        <div className="quiz-modal-header">
          <h3>Quiz: {topicTitle}</h3>
          <button onClick={onClose} className="quiz-modal-close-button" aria-label="Close modal">&times;</button>
        </div>
        <div className="quiz-modal-content">
          {isLoading && <div className="loader" role="status" aria-label="Generating quiz"></div>}
          {error && <p className="error">{error}</p>}
          {quizData && quizData.map((q, index) => (
            <div key={index} className="quiz-question">
                <p className="quiz-question-text">{index + 1}. {q.question}</p>
                <div className="quiz-options">
                    {q.options.map((option, optIndex) => (
                        <button
                            key={optIndex}
                            className={`quiz-option-button ${getButtonClass(index, option)}`}
                            onClick={() => handleAnswerSelect(index, option)}
                            disabled={userAnswers[index] !== undefined}
                        >
                           {option}
                        </button>
                    ))}
                </div>
                {userAnswers[index] !== undefined && (
                    <div className="quiz-explanation">
                        <strong>Explanation:</strong> {q.explanation}
                    </div>
                )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}