/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useEffect, useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { marked } from 'marked';

export function AiModal({ isOpen, prompt, onClose }) {
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen || !prompt) {
      return;
    }

    const callGemini = async () => {
      setIsLoading(true);
      setError('');
      setResponse('');

      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const result = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        
        const textToParse = result.text;
        
        // Add a defensive check to ensure we only parse strings.
        if (typeof textToParse === 'string') {
          const htmlResponse = await marked.parse(textToParse);
          setResponse(htmlResponse);
        } else {
          // Handle cases where the API returns no text (e.g., safety blocking)
          setResponse('');
          setError('The AI returned an empty response. This may be due to safety settings.');
        }

      } catch (e) {
        console.error("Gemini API call failed", e);
        setError('Sorry, the AI is unable to respond at the moment. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    callGemini();
  }, [isOpen, prompt]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="ai-modal-overlay" onClick={onClose}>
      <div className="ai-modal" onClick={(e) => e.stopPropagation()}>
        <div className="ai-modal-header">
          <h3>AI Assistant ✨</h3>
          <button onClick={onClose} className="ai-modal-close-button" aria-label="Close modal">&times;</button>
        </div>
        <div className="ai-modal-content">
          {isLoading && <div className="loader" role="status" aria-label="Loading AI response"></div>}
          {error && <p className="error">{error}</p>}
          {response && (
            <div
              className="markdown-body"
              dangerouslySetInnerHTML={{ __html: response }}
            />
          )}
        </div>
      </div>
    </div>
  );
}