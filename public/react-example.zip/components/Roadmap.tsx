/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
export function Roadmap({ sections, activeTopic, onTopicClick, onViewedCheck, onTopicHover }) {
  return (
    <div className="roadmap-container">
      <h2 className="roadmap-title">BlueRabbit</h2>
      <p className="roadmap-intro">
        A comprehensive guide to modern web development, from first principles.
        Select a topic to begin.
      </p>
      <div className="roadmap-grid">
        {sections.map((section) => (
          <div key={section.title} className="roadmap-card">
            <h3 className="roadmap-card-title">{section.title}</h3>
            <ul className="roadmap-topic-list">
              {section.topics.map((topic) => (
                <li
                  key={topic}
                  className={`roadmap-topic-item ${activeTopic === topic ? 'active' : ''} ${onViewedCheck(topic) ? 'viewed' : ''}`}
                  onMouseEnter={() => onTopicHover(topic)}
                >
                  <button
                    className="roadmap-topic-button"
                    onClick={() => onTopicClick(topic)}
                    aria-current={activeTopic === topic ? 'page' : undefined}
                  >
                    {topic}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}