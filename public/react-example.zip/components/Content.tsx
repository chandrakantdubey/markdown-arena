/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { Roadmap } from './Roadmap.js';
import { TopicNavigation } from './TopicNavigation.js';
import { MarkdownRenderer } from './MarkdownRenderer.js';

export function Content({
  isLoading,
  error,
  generatedContent,
  sections,
  activeTopic,
  onRoadmapTopicClick,
  isTopicViewed,
  prefetchTopic,
  onTopicClick,
  onAiAction,
  onGenerateQuiz,
  glossary,
  onTermClick,
}) {
  return (
    <main className="content">
      {isLoading &&
          <div className="loader" role="status"
                aria-label="Loading content"></div>}
      {error && <p className="error">{error}</p>}
      {!isLoading && !generatedContent && !error && (
          <Roadmap
            sections={sections}
            activeTopic={activeTopic}
            onTopicClick={onRoadmapTopicClick}
            onViewedCheck={isTopicViewed}
            onTopicHover={prefetchTopic}
          />
      )}
      {generatedContent && (
        <>
          <MarkdownRenderer
            markdownContent={generatedContent}
            onAiAction={onAiAction}
            glossary={glossary}
            onTermClick={onTermClick}
          />
          <div className="topic-actions">
            <button
              className="ai-button generate-quiz-button"
              onClick={() => onGenerateQuiz(activeTopic, generatedContent)}
            >
              Test Your Knowledge: Generate a Quiz ✨
            </button>
          </div>
          <TopicNavigation
            sections={sections}
            activeTopic={activeTopic}
            onTopicClick={onTopicClick}
          />
        </>
      )}
    </main>
  );
}