
# Backend from First Principles

This project is an interactive, web-based learning platform designed to teach backend engineering concepts from the ground up. It uses a simple and powerful stack to deliver a rich, AI-enhanced learning experience, dynamically rendering educational content written in Markdown.

The application is built with:
- **React**: For the user interface and component-based architecture.
- **Gemini API**: To power AI features like code explanations and quiz generation.
- **marked**: For parsing Markdown content into HTML.
- **highlight.js**: For beautiful and accurate syntax highlighting in code blocks.
- **mermaid.js**: For rendering complex diagrams and flowcharts from code.

## Features

- **Dynamic Content**: Lessons are fetched and rendered on-demand from local Markdown files.
- **Interactive Navigation**: A searchable, collapsible sidebar, generated from `data.md`, allows for easy navigation between topics.
- **AI-Generated Quizzes**: Test your knowledge at the end of each topic with unique quizzes generated on the fly by the Gemini API.
- **Interactive Glossary**: Key backend engineering terms are automatically highlighted and linked to pop-up definitions.
- **AI-Powered Explanations**: Dissect complex topics and code snippets with in-depth explanations from an AI assistant.
- **Rich Content Rendering**:
    - **Syntax Highlighting**: Code blocks in various languages are automatically highlighted for readability using `highlight.js`.
    - **Diagrams as Code**: Mermaid syntax within Markdown is transformed into clean SVG diagrams.
    - **Interactive Code Tabs**: Display code examples in multiple languages within a single, tabbed interface.
- **Responsive Design**: The layout is optimized for both desktop and mobile viewing.

---

## How Content is Rendered

The core rendering logic is designed to enhance standard Markdown with interactive elements. This is achieved through a multi-step process within the `MarkdownRenderer.tsx` component.

1.  **Fetching Markdown**: When a user clicks a topic, the application fetches the corresponding `.md` file from the `/content` directory.
2.  **Parsing with `marked`**: The raw Markdown text is passed to the `marked.parse()` function. This converts the text into a standard HTML string.
3.  **Initial Render**: The resulting HTML string is set into the React state and rendered to the page using the `dangerouslySetInnerHTML` prop. At this point, the content is just static HTML.
4.  **Post-Render Enhancement (`useEffect`)**: This is the key step. A `useEffect` hook, which runs *after* the static HTML has been rendered to the DOM, performs several "enhancements":
    -   **Mermaid Diagram Rendering**:
        - The hook scans the newly rendered content for any `<code>` blocks with the class `language-mermaid`.
        - It extracts the raw text content (the Mermaid diagram syntax) and replaces the parent `<pre>` tag with a new `<div>` container.
        - It then calls `mermaid.render()`, and the resulting SVG is injected directly into the new `<div>`, bringing the diagram to life.
    -   **Code Tab Interactivity**:
        - The hook scans for any `<div>` with the class `.code-tabs`.
        - It attaches native JavaScript `click` event listeners to each button, which toggle the `.active` class on the corresponding content panes based on their `data-lang` attributes.
    -   **Glossary Term Cross-Linking**:
        - The hook also references a glossary of terms parsed from `content/glossary.md`.
        - It scans the text nodes of the rendered content for the first occurrence of each term.
        - When a term is found, it's wrapped in a special `<button class="term-link">` element.
        - An event listener is attached to the main content area, which listens for clicks on these buttons and displays a tooltip with the term's definition.

This post-processing approach allows us to write content in nearly standard Markdown and use client-side JavaScript to progressively enhance it with rich, interactive features.

---

## Project Structure

```
/
├── index.html          # Main HTML file, sets up importmap
├── index.css           # All application styles
├── index.tsx           # Main React application entry point
├── data.md             # Defines the structure and topics for the sidebar
├── README.md           # This file
├── utils/
│   └── slugify.js      # Helper function for converting titles to filenames
├── components/
│   ├── App.tsx         # Main application component
│   ├── Sidebar.tsx     # The left-hand navigation sidebar
│   ├── Content.tsx     # The main content area
│   ├── Roadmap.tsx     # The initial landing page view
│   ├── MarkdownRenderer.tsx # Renders markdown and enhances it
│   ├── TopicNavigation.tsx  # Previous/Next topic buttons
│   ├── AiModal.tsx     # Modal for AI explanations
│   ├── QuizModal.tsx   # Modal for AI-generated quizzes
│   ├── GlossaryModal.tsx # Modal for viewing all glossary terms
│   └── DefinitionTooltip.tsx # Pop-up for term definitions
└── content/
    ├── glossary.md     # Source file for all glossary terms
    ├── http-protocol.md
    ├── routing.md
    └── ... (all other topic markdown files)
```

## How to Add a New Topic

Adding a new lesson is simple:

1.  **Add to Sidebar**: Open `data.md` and add your new topic title to the desired section. The format is `1. **Topic Name**`.

    ```markdown
    ### **Section Title**

    1. **Existing Topic**
    2. **My New Topic**  <-- Add your new topic here
    ```

2.  **Create Markdown File**: Create a new file in the `/content` directory. The filename **must** be the "slugified" version of your topic title (lowercase, spaces replaced with hyphens, special characters removed).
    -   `My New Topic` becomes `my-new-topic.md`
    -   `gRPC` becomes `grpc.md`

3.  **Write Content**: Write your lesson in the new file using standard Markdown. You can also use the special syntax below.

---

## Special Markdown Syntax

To render advanced components, you can embed specific HTML structures directly into your Markdown files.

### Mermaid Diagrams

To create a diagram, use a standard code block with the language specifier `mermaid`.

````markdown
```mermaid
graph TD
    A[Start] --> B{Is it working?};
    B -- Yes --> C[End];
    B -- No --> D[Check logs];
```
````

### Code Tabs

To create a set of interactive code tabs, use the following HTML structure:

```html
<div class="code-tabs">
  <div class="tab-buttons">
    <button class="tab-button active" data-lang="nodejs">Node.js</button>
    <button class="tab-button" data-lang="python">Python</button>
  </div>
  <div class="tab-content active" data-lang="nodejs">
<pre><code class="language-javascript">
// Your Node.js code here
</code></pre>
  </div>
  <div class="tab-content" data-lang="python">
<pre><code class="language-python">
# Your Python code here
</code></pre>
  </div>
</div>
```
**Important**: The `active` class should be on the first button and first content pane to ensure they are visible by default.

### Further Reading Box

To add a "Further Reading" section with a distinct style, use this HTML structure:

```html
<div class="further-reading">
<h3>Further Reading</h3>
<ul>
  <li><a href="..." target="_blank">Link Title</a></li>
</ul>
</div>
```
